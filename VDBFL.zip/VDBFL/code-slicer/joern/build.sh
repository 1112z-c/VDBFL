#!/bin/sh

gradle deploy -x test
