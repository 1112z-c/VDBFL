
void function_location_1() {
	printf("Hello");
}

void function_with_loop_1 () {
        int x = 1;
        while (x < 100) {
                while (x < 50) {
                        x = x+1;
                }
                x = x + 1;
        }
        print(x);
}
