package ast.expressions;

public class Sizeof extends Expression
{

}
