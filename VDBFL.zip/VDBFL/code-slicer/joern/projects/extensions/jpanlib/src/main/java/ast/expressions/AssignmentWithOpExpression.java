package ast.expressions;

public class AssignmentWithOpExpression extends AssignmentExpression
{

}
