package ast.expressions;

public class ExclusiveOrExpression extends BinaryOperationExpression
{
}
