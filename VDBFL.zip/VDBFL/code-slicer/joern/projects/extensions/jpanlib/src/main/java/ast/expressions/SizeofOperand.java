package ast.expressions;

public class SizeofOperand extends Expression
{

}
