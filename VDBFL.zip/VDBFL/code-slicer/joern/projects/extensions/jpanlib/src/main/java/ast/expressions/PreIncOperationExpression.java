package ast.expressions;

public class PreIncOperationExpression extends PreIncDecOperationExpression
{
}
