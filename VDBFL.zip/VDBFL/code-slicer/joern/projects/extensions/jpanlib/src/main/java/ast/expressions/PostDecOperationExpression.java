package ast.expressions;

public class PostDecOperationExpression extends PostIncDecOperationExpression
{
}
