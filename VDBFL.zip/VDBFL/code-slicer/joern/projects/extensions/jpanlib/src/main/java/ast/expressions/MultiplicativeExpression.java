package ast.expressions;

public class MultiplicativeExpression extends BinaryOperationExpression
{
}
