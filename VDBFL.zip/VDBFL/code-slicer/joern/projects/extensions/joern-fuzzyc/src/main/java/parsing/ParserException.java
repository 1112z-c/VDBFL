package parsing;

public class ParserException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
}
