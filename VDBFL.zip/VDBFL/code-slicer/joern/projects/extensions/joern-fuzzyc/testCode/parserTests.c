void new_operator_test()
{
  long *buffer;
  size_t num_elements;  
  buffer = new long[num_elements];
}
