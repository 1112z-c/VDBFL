package ast.php.expressions;

import ast.expressions.Identifier;

public class TypeHint extends Identifier
{
}
