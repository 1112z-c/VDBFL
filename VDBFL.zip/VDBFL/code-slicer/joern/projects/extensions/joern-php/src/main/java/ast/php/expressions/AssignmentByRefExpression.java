package ast.php.expressions;

import ast.expressions.AssignmentExpression;

public class AssignmentByRefExpression extends AssignmentExpression
{

}
