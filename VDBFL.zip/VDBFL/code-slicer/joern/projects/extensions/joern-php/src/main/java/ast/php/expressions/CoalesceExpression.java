package ast.php.expressions;

import ast.expressions.BinaryExpression;

public class CoalesceExpression extends BinaryExpression
{
}
