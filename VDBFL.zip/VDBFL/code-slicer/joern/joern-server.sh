#!/bin/sh
./projects/octopus/octopus-server.sh
